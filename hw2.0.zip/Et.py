"""
This code determines the variance between Ft and St.
"""
import Ft
import St
#The variance definition:
def e(tValue, nValue):
    return Ft.f(tValue)-St.s(tValue,nValue)
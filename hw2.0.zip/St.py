import math
"""
This code uses the sum of sines to approximate the function as the iteration, n, approaches infitity.
"""
# Local variables:
T=2*math.pi
# Fourier series expansion equation definition:
def s(tValue, nValue):
    sum = 0
    a=(4/math.pi)
    for k in range(1,nValue+1):
        b=(1/(2*k-1))*(math.sin((2*(2*k-1)*math.pi*tValue)/T))
        sum += b
    return sum*a
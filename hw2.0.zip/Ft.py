import math
"""
This code uses the sum of sines to approximate the function.
"""
# Local variables:
T = 2*math.pi
minInput = -T/2
maxInput = T/2
# Piecewise function definition:
def f(tValue):
    if tValue > 0 and tValue < maxInput:
        return 1
    elif tValue == maxInput:
        return 0
    elif tValue > minInput and tValue < 0:
        return -1